# Sample Bug Report

Attendance marked absent issue.
