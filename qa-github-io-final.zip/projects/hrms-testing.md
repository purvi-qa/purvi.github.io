# HRMS Testing

Attendance, shifts, approvals testing.
